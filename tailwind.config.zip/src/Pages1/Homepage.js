import React from 'react'
import Header from '../Components/Header'
import Navbar from '../Components/Navbar'
import ImageSlideshow from '../Components/ImageSlideshow'
import FAQs from '../Components/FAQs'
import Footer from '../Components/Footer'
import { Link } from 'react-router-dom'
// import Solution from './Solution'
// import Staffing from './Staffing'
// import Training from './Training'
// import HomePage/ from './Gaurav / HomePage'
// import Testimonial from '../Components/Testimonial'
import OurPastPlacement from '../Pages1/OurPastPlacement'
import About from './About'

function Homepage() {
    return (
        <div>
            {/* <Link to='/home'> */}
            <Header />
            {/* <Navbar /> */}

            {/* images slideshow */}
            <ImageSlideshow />
            {/* <Solution />
                <Staffing />
                <Training /> */}

            {/*Frequesntly asked questions  */}
            {/* <OurPastPlacement /> */}
            {/* <About /> */}

            {/* <Testimonial /> */}
            <FAQs />

            {/* footer */}
            {/* <Footer /> */}
            {/* </Link> */}
        </div>
    )
}

export default Homepage