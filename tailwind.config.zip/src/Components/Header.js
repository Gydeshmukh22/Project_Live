import React from 'react'
// import Login from '../Pages1/Login'
import { Link } from 'react-router-dom'

function Header() {
    return (
        <div>
            <div className="justify-around flex  bg-indigo-950 w-[full] leading-[50px] p-3">
                <h1 className="flex ml-2 p-2 text-3xl font-bold text-white  ">Softronix</h1>
                <ul className="flex space-x-10 text-white-900">

                    <Link to='/productsandservises'>
                        <li>Product & Services</li>
                    </Link>

                    <Link to='/about'>
                        <li>About Us</li>
                    </Link>

                    <Link to='/contactus'>
                        <li>Contact Us</li>
                    </Link>

                    <Link to='/login'>
                        <li>Login</li>
                    </Link>


                </ul>
            </div>

        </div>
    )
}

export default Header