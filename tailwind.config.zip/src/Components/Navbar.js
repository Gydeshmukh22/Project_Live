import React from 'react'

function Navbar() {



    return (
        <>
            < nav >
                {/* <p>HOME</p>


                <br /> */}

                <p>ABOUT US</p>

                <br />
                <p>SERVICES</p>

                <br />
                <p>INTERNSHIP</p>
                <br />
                <p>NEW BATCH</p>
                <br />
                <p>CONTACT US </p>
            </nav >
        </>
    )
}

export default Navbar