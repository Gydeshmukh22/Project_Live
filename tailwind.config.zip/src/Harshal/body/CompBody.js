import React from 'react'
import './body.css';
const CompBody = () => {
    return (
        <div className='body-div'>

        </div>
    )
}


export default CompBody



