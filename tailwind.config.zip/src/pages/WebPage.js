import React from 'react'

function WebPage() {
    return (
        <div>WebPage</div>
    )
}

export default WebPage